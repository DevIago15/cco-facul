package com.example.app_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
