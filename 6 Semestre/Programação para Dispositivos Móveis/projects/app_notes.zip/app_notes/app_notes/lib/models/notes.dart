class Note {
  final String titulo;
  final String descricao;

  Note({required this.titulo, required this.descricao});
}